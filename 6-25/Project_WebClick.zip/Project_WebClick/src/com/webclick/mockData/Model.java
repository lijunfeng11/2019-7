package com.webclick.mockData;

import java.io.*;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * 类名称: Model
 * 类描述: 模拟电商日志
 */
public class Model {
    private static Random random = new Random();
    private static StringBuffer sb = null;

    //设置时间的区间范围
    private static String startTime = "2018-01-01 00:00:00";
    private static String endTime = "2018-12-31 23:59:59";
    //url
    private static final String[] url_suffix = ".com,.cn,.gov,.edu,.net,.org,.int,.mil,.biz,.info,.js,.css,.jpg".split(",");
    public static String base = "abcdefghijklmnopqrstuvwxyz0123456789";

    private static List<String> citys = new ArrayList<>();

    /**
     * 生成IP地址
     *
     * @return
     */
    private static String genIp() {
        String ip = "";
        sb = new StringBuffer();
        for (int i = 0; i < 4; i++) {
            ip = String.valueOf(random.nextInt(256));
            sb.append(ip).append(".");
        }
        ip = sb.substring(0, sb.length() - 1);
        return ip;
    }

    /**
     * 生成随机时间
     *
     * @param startTime
     * @param endTime
     * @return
     */
    private static String genBuildTime(String startTime, String endTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long startTimeTS = 0L;
        long endTimeTS = 0L;
        long randomTimeTS = 0L;
        try {
            Date start_TimeTS = sdf.parse(startTime);
            startTimeTS = start_TimeTS.getTime();
            Date end_TimeTS = sdf.parse(endTime);
            endTimeTS = end_TimeTS.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        randomTimeTS = (long) (startTimeTS + (endTimeTS - startTimeTS) * Math.random());
        return sdf.format(new Date(randomTimeTS));
    }

    /**
     * 随机生成请求方式
     *
     * @return
     */
    private static String genRequest() {
        String[] requset = new String[]{"POST", "GET"};
        return requset[random.nextInt(2)];
    }

    /**
     * 随机生成请求Url
     *
     * @return
     */
    private static String genURl(int lMin, int lMax) {
        sb = new StringBuffer();
        int length = (int) (Math.random() * (lMin - lMax + 1) + lMax);
        for (int i = 0; i < length; i++) {
            int number = (int) (Math.random() * base.length());
            sb.append(base.charAt(number));
        }
        sb.append(url_suffix[(int) (Math.random() * url_suffix.length)]);
        return sb.toString();
    }

    /**
     * 随机生成请求所用协议
     *
     * @return
     */
    private static String genRequestProtocol() {
        String[] requestProtocol = new String[]{"HTTP/1.1", "HTTP/1.0"};
        return requestProtocol[random.nextInt(2)];
    }

    /**
     * 随机生成响应码
     */
    private static String genStatus() {
        String[] status = new String[]{"200", "201", "202", "203", "101", "300", "301", "302", "303", "400", "404", "500", "501"};
        return status[random.nextInt(status.length)];
    }

    /**
     * 随机生成数据流量
     */
    public static String genFlowSize() {
        int num = random.nextInt(100000);
        DecimalFormat df = new DecimalFormat("0000");
        String duration = df.format(num);
        return duration;
    }

    /**
     * 随机生成来访Url
     *
     * @return
     */
    private static String genReferer(int lMin, int lMax) {
        sb = new StringBuffer();
        int length = (int) (Math.random() * (lMin - lMax + 1) + lMax);
        sb.append("http://");
        for (int i = 0; i < length; i++) {
            int number = (int) (Math.random() * base.length());
            sb.append(base.charAt(number));
        }
        sb.append(url_suffix[(int) (Math.random() * url_suffix.length)]);
        return sb.toString();
    }

    /**
     * 随机生成PC浏览器
     *
     * @return
     */
    private static String genPCBrowser() {
        String[] status = new String[]{"Google Chrome Chromium/Blink", "Mozilla Firefox Gecko", "OPera blink", "Safari webkit", "Windows Internet Explorer Trident"};
        return status[random.nextInt(status.length)];
    }

    /**
     * 随机生成手机浏览器
     *
     * @return
     */
    private static String genPhoneBrowser() {
        String[] status = new String[]{"IE Trident", "Opera Webkit", "Firefox ", "Chrome webkit", "QQBrowser Webkit X5", "UCBrowser Webkit X3"};
        return status[random.nextInt(status.length)];
    }

    /**
     * 随机生成地理位置
     */
    public static String genCity() {
        try {
            File file = new File("/home/citys.txt");
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = null;
            while ((line = br.readLine()) != null) {
                String[] str = line.split(" ");
                for (String s : str) {
                    citys.add(s);
                }
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return citys.get(random.nextInt(citys.size()));
    }

    /**
     * 随机生成操作系统
     *
     * @return
     */
    public static String genOS() {
        String[] OSs = new String[]{"android 8.0", "ios", "windows", "windows", "windows", "Mac OS X"};
        return OSs[random.nextInt(OSs.length)];
    }


    /**
     * 拼接数据
     */
    private static String product() {
        String ip = genIp();
        String buildTime = genBuildTime(startTime, endTime);
        String city = genCity();
        String request = genRequest();
        String requestUrl = genURl(10, 30);
        String requestProtocol = genRequestProtocol();
        String status = genStatus();
        String flowSize = genFlowSize();
        String referer = genReferer(10, 30);
        String os = genOS();
        String phoneBrowser = null;
        String browser = null;
        sb = new StringBuffer();
        if (os.equals("android 8.0") || os.equals("ios")) {
            phoneBrowser = genPhoneBrowser();
            sb.append(ip).append(" ")
                    .append(buildTime).append(" ")
                    .append(city).append(" ")
                    .append(os).append(" ")
                    .append(request).append(" ")
                    .append(requestUrl).append(" ")
                    .append(requestProtocol).append(" ")
                    .append(status).append(" ")
                    .append(flowSize).append(" ")
                    .append(referer).append(" ")
                    .append(phoneBrowser);
        }else if (os.equals("windows") || os.equals("Mac OS X")){
            browser = genPCBrowser();
            sb.append(ip).append(" ")
                    .append(buildTime).append(" ")
                    .append(city).append(" ")
                    .append(os).append(" ")
                    .append(request).append(" ")
                    .append(requestUrl).append(" ")
                    .append(requestProtocol).append(" ")
                    .append(status).append(" ")
                    .append(flowSize).append(" ")
                    .append(referer).append(" ")
                    .append(browser);
        }
        return sb.toString();
    }


    /**
     * 拼接数据 写入文件
     */
    public static void writeLog(String filePath) {
        try {
            OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(filePath, true));
//            Thread.sleep(100);
            String log = product();
//            System.out.println(log);
            osw.write(log);
            osw.write("\n");
            //把缓冲中的数据刷入到本地
            osw.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public static void main(String[] args) {
//        System.out.println(product());
        int i = 0;
        String filePath = "/home/access.log";
        while (i < 10000) {
            i++;
            writeLog(filePath);
            try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
    }
}
