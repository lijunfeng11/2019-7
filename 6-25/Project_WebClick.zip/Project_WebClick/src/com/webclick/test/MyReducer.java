package com.webclick.test;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text, IntWritable, Text, IntWritable>{

	@Override
	protected void reduce(Text key, Iterable<IntWritable> iter,Context context) throws IOException, InterruptedException {

		//业务逻辑：
		// key = hadoop
		// iter = [1 , 1]
		int sum = 0; //计数器
		//在遍历容器的过程中，获取每一个元素：
		// one = 1
		for (IntWritable one : iter) {
			sum += one.get(); // one.get() = 1      sum = sum + 1;
		}
		//输出：key = 单词   value = 累加和
		context.write(new Text(key) , new IntWritable(sum));
	}
}







