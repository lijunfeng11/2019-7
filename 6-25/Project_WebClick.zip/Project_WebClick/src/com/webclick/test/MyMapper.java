package com.webclick.test;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *   map: 
 *   1)继承mapper父类；
 */
public class MyMapper extends Mapper<LongWritable, Text, Text, IntWritable>{

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

		//1) 获取一行数据；切割
		// hadoop spark
		String line = value.toString();
		//words = [hadoop,spark]
		String[] words = line.split(" ");
		//2) 输出：<单词 ， 1>
		//通过循环，获取数组中的每一个元素：
		//word = hadoop
		for (String word : words) {
			//输出：key = 单词，value = 1
			context.write(new Text(word) , new IntWritable(1));
		}
	}
}











