package com.webclick.mr.PageviewMode;

import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.webclick.daomain.WebLogBean;
/**
* <p>Title: ClickStreamPageview</p>  
* <p>Description: 
 * 输入数据是ETL（WeblogPreProcess）之后的数据；
 * 将清洗之后的日志梳理出点击流pageviews模型数据：
 * 		1）区分出每一次会话，给每一次visit（session）增加了session-id(随机uuid)
 * 		2）梳理出每一次会话中所访问的每个页面（请求时间，url，停留时长，以及该页面在这次session中的序号）
 * 		3）保留referral_url,  body_bytes_send.  useragent
* </p>  
* @author 优逸客大数据开发团队  
* @date 2018年10月1日
 */
public class ClickStreamPageview extends Configured implements Tool{
	
	private static class MapTask extends Mapper<LongWritable, Text, Text, WebLogBean>{
		
		Text ip = new Text();
		WebLogBean bean = new WebLogBean();
		
		@Override
		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			
			//true61.148.244.188-2013-09-18 07:10:50/hadoop-hive-intro/20014764"-""Mozilla/5.0(Linux;U;Android4.1.2;zh-cn;GT-I9300Build/JZO54K)AppleWebKit/534.30(KHTML,likeGecko)Version/4.0MobileSafari/534.30V1_AND_SQ_4.2.1_3_YYB_D"
			String line = value.toString();
			String[] fields = line.split("\001");
			
			//非法校验：
			if(fields.length < 9){
				return;
			}
			
			//将切分出来的各字段set到weblogbean中:
			boolean valid = "true".equals(fields[0]) ? true : false; 
			String remote_addr = fields[1];
			String remote_user = fields[2];
			String time_local = fields[3];
			String request = fields[4];
			String status = fields[5];
			String body_bytes_sent = fields[6];
			String http_referer = fields[7];
			String http_user_agent = fields[8];
			
			//封装对象：
			bean.set(valid, remote_addr, remote_user, time_local, request, status, body_bytes_sent, http_referer, http_user_agent);
			
			//有效记录才进入后续处理
			if(bean.isValid()){
				ip.set(bean.getRemote_addr());
				//key = ip   value=bean
				context.write(ip , bean);
			}
		}
	}
	
	
	/*
	 * 按照提取设计好的跑批时间，reduce聚合统计的是一个时间段内的数据
	 */
	private static class ReduceTask extends Reducer<Text, WebLogBean, NullWritable, Text>{
		
		Text totalData = new Text();
		
		@Override
		protected void reduce(Text userIp, Iterable<WebLogBean> iterator,Context context)  throws IOException, InterruptedException {
			
			List<WebLogBean> beans = new ArrayList<WebLogBean>();
			// 将一个用户的访问记录全部获取，放到集合中, 然后进行排序：
			try{
				for(WebLogBean bean : iterator){
					
					WebLogBean webLogBean = new WebLogBean();
					try {
						//内存优化：使用复制出来的新的对象来替代旧的对象，从而减少对内存的使用：
						BeanUtils.copyProperties(webLogBean, bean);
					} catch (Exception e) {
						e.printStackTrace();
					}
					//将bean添加到list中：目的：bean之间的排序
					beans.add(webLogBean);
				}
				
				//将所有bean按时间先后顺序升序排序：
				Collections.sort(beans, new Comparator<WebLogBean>() {

					@Override
					public int compare(WebLogBean o1, WebLogBean o2) {
						try {
							Date d1 = toDate(o1.getTime_local());
							Date d2 = toDate(o2.getTime_local());
							if (d1 == null || d2 == null) return 0;
							
							return d1.compareTo(d2);  //时间默认升序
						} catch (Exception e) {
							e.printStackTrace();
							return 0;
						}
					}	
				});
				
				
				/**
				 * 以下逻辑为：从有序bean中分辨出各次visit，并对一次visit中所访问的page按顺序标号step
				 * 	1）当只有一条
				 * 	2）当有多条
				 * 					当第一条 continue
				 * 					当不是第一条，时间在30分钟内吗?在, 写出去, step+1, 不在就step =1, 重置sessionid				
				 * 					当最后一条，写出去, 设置默认停留时长为60s
				 */
				int step = 1; //默认访问第一个页面：
				
				String session = UUID.randomUUID().toString();//随机生成uuid，作为session；
				
				for(int i=0;i<beans.size();i++){
					
					WebLogBean bean = beans.get(i);
					
					// 1、如果一个用户只有一条记录； 如果仅有1条数据，则直接输出:
					if (1 == beans.size()) {
						
						// 设置默认停留时长为60s
						totalData.set(session+"\001"+userIp.toString()+"\001"+bean.getRemote_user() + "\001" + bean.getTime_local() + "\001" + bean.getRequest() + "\001" + 
															step + "\001" + (60) + "\001" + bean.getHttp_referer() + "\001" + bean.getHttp_user_agent() + "\001" + bean.getBody_bytes_sent() + "\001" + bean.getStatus());
						
						context.write(NullWritable.get(), totalData);

						break;
					}

					//2、如果不止1条数据，则将第一条跳过不输出，遍历第二条时再输出:
					if (i == 0) { 
						continue;
					}

					//当第二条时，开始执行下面逻辑：
					// 求近本次（第二条）---上次（第一条）之间的时间差
					long timeDiff = timeDiff(toDate(bean.getTime_local()), toDate(beans.get(i - 1).getTime_local()));
					
					/**
					 * 如果本次-上次时间差<30分钟，说明两次访问时长是在同一个session内，
					 * 则输出前一次（第一条）的页面访问信息					
					 */
					if (timeDiff < 30 * 60 * 1000) {			
						
						totalData.set(session+"\001"+userIp.toString()+"\001"+beans.get(i - 1).getRemote_user() + "\001" + beans.get(i - 1).getTime_local() + "\001" + beans.get(i - 1).getRequest() + "\001" + step + "\001" + (timeDiff / 1000) + "\001" + beans.get(i - 1).getHttp_referer() + "\001"
															+ beans.get(i - 1).getHttp_user_agent() + "\001" + beans.get(i - 1).getBody_bytes_sent() + "\001" + beans.get(i - 1).getStatus());
						//输出上次页面访问信息：
						context.write(NullWritable.get(), totalData);
						
						step++; // 访问页面数加1；
					} else {
						
					/**
					 * 如果本次-上次时间差>30分钟，说明两次访问时长已经不在同一个session内，
					 * 则输出前一次的页面访问信息，同时将step重置，以分隔为新的visit
					 */
						totalData.set(session+"\001"+userIp.toString()+"\001"+beans.get(i - 1).getRemote_user() + "\001" + beans.get(i - 1).getTime_local() + "\001" + beans.get(i - 1).getRequest() + "\001" + (step) + "\001" + (60) + "\001" + beans.get(i - 1).getHttp_referer() + "\001"
														+ beans.get(i - 1).getHttp_user_agent() + "\001" + beans.get(i - 1).getBody_bytes_sent() + "\001" + beans.get(i - 1).getStatus());
						//输出上次页面访问信息：
						context.write(NullWritable.get(), totalData);
						
						// 输出完上一条之后，重置step编号、session
						step = 1;
						session = UUID.randomUUID().toString();
					}
					
					//3、如果此次遍历的是最后一条，则将本条直接输出:
					if (i == beans.size() - 1) {
						
						// 设置默认停留时长为60s
						totalData.set(session+"\001"+userIp.toString()+"\001"+bean.getRemote_user() + "\001" + bean.getTime_local() + "\001" + bean.getRequest() + "\001" 
															+ step + "\001" + (60) + "\001" + bean.getHttp_referer() + "\001" + bean.getHttp_user_agent() + "\001" + bean.getBody_bytes_sent() + "\001" + bean.getStatus());
						
						context.write(NullWritable.get(), totalData);
					}
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		private Date toDate(String timeStr) throws Exception {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
			return df.parse(timeStr);
		}


		private long timeDiff(Date time1, Date time2) throws Exception {

			return time1.getTime() - time2.getTime();
		}
	}
	
	
	@Override
	public int run(String[] arg0) throws Exception {
		
		Configuration conf = getConf();

		Job job = Job.getInstance(conf , "pageview模型");

		job.setJarByClass(ClickStreamPageview.class);
		
		job.setMapperClass(MapTask.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(WebLogBean.class);
		job.setReducerClass(ReduceTask.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		FileInputFormat.addInputPath(job, new Path(arg0[0]));
		FileOutputFormat.setOutputPath(job, new Path(arg0[1]));
			
		return job.waitForCompletion(true) ? 0 : 1;
	}
	
	
	public static void main(String[] args) throws Exception {
		
		//本地测试：
		//args = new String[] {"testData/access.log" , "testData/preLog"};
		
		//集群测试：
		//args = new String[] {"/project/webClick/preLog" , "/project/webClick/pageviewsModel"};
		
		Configuration conf = new Configuration();
		//conf.set("fs.defaultFS", "hdfs://node1:8020");
		
		//创建一个主类对象：
		ClickStreamPageview pageview = new ClickStreamPageview();
		
		int status = ToolRunner.run(conf, pageview , args);
		
		System.exit(status);
	}
}







































