package com.webclick.mr.pre;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.webclick.daomain.WebLogBean;

/**
* <p>Title: WeblogPreProcess</p>  
* <p>Description: ETL(对用户行为日志原始数据，按照业务需求进行预处理)</p>  
* @author 优逸客大数据开发团队  
* @date 2018年10月1日
 */
public class WeblogPreProcess extends Configured implements Tool{
	
	private static class MapTask extends Mapper<LongWritable, Text, Text, NullWritable>{
		
		//数据字典表：用来存储网站有效url请求：
		Set<String> pages = new HashSet<String>();
		
		Text dataStr = new Text();
		NullWritable nulls = NullWritable.get();
		
		/**
		 * 根据业务分析，统计出哪些url请求是需要的，其他的就不接收请求；
		 * 只接收以下url请求：这些才是真实的PV；
		 * 
		 * 在mr程序运行时，首先一次性加载到一个set中，后续的每一天url与之匹配；
		 */
		@Override
		protected void setup(Context context) throws IOException, InterruptedException {
			pages.add("/about");
			pages.add("/black-ip-list/");
			pages.add("/cassandra-clustor/");
			pages.add("/finance-rhive-repurchase/");
			pages.add("/hadoop-family-roadmap/");
			pages.add("/hadoop-hive-intro/");
			pages.add("/hadoop-zookeeper-intro/");
			pages.add("/hadoop-mahout-roadmap/");
		}
		
		@Override
		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			
			String line = value.toString();
			//第一步：对输入的每一行数据进行校验：
			WebLogBean webLogBean = WebLogParser.parser(line);
			//第二步：过滤掉：js/图片/css等静态资源，只获取有效url:
			WebLogParser.filtStaticResource(webLogBean, pages);
			 //第三步： 如果数据校验不合法，就直接返回，不输出
			if(!webLogBean.isValid()){
				return;  
			}
			
			dataStr.set(webLogBean.toString());
			
			context.write(dataStr , nulls);
		}
	}
	
	
	@Override
	public int run(String[] arg0) throws Exception {
		
		Configuration conf = getConf();
		
		Job job = Job.getInstance(conf , "ETL");

		job.setJarByClass(WeblogPreProcess.class);

		job.setMapperClass(MapTask.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NullWritable.class);

		FileInputFormat.setInputPaths(job, new Path(arg0[0]));
		FileOutputFormat.setOutputPath(job, new Path(arg0[1]));
		
		//不需要reduce，必须指定，否则默认会有reduce;
		job.setNumReduceTasks(0);
		
		return job.waitForCompletion(true) ? 0 : 1;
	}
	
	
	public static void main(String[] args) throws Exception {
		
		//本地测试：
		//args = new String[] {"testData/access.log" , "testData/preLog"};
		
		//集群测试：
		//args = new String[] {"/project/webClick/logs/18-10-01" , "/project/webClick/preLog"};
		
		Configuration conf = new Configuration();
		//conf.set("fs.defaultFS", "hdfs://node1:8020");
		//创建一个主类对象：
		WeblogPreProcess preProcess = new WeblogPreProcess();
		
		int status = ToolRunner.run(conf, preProcess , args);
		
		System.exit(status);
	}
}








































