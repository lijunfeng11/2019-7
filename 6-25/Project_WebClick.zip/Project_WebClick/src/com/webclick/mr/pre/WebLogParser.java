package com.webclick.mr.pre;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Set;

import com.webclick.daomain.WebLogBean;
/**
* <p>Title: WebLogParser</p>  
* <p>Description: 
*  * 对日志进行预处理：1）处理原始日志，过滤出真实PV；（因为静态资源的请求不算,js请求不算）
 * 								  2）转换时间格式；
 * 								  3）对缺失字段进行填充默认值；
 * 								  4）对记录标记valid和invalid；
* </p>  
* @author 优逸客大数据开发团队  
* @date 2018年10月1日
 */
public class WebLogParser {
	
	//外部数据源时间格式
	public static SimpleDateFormat df1 = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss", Locale.US);
	//转化后的时间格式
	public static SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
	
	/**
	 * 通过对输入的每一行数据进行校验，然后把相应维度抽取出来，返回一个bean
	 */
	public static WebLogBean parser (String line){
		
		WebLogBean webLogBean = new WebLogBean();
		
		String[] arr = line.split(" ");
		
		//如果字段有11以上，则认为是合法数据；
		if(arr.length > 11){
			
			webLogBean.setRemote_addr(arr[0]);
			webLogBean.setRemote_user(arr[1]);
			
			/**
			 * 时间格式的转换： [18/Sep/2013:06:49:18 +0000] 
			 */
			String time_local = formatDate(arr[3].substring(1)); //去掉中括号
			// 如果时间字段有缺省，就赋默认值；
			if(null == time_local){
				time_local="-invalid_time-"; 
			}
			webLogBean.setTime_local(time_local);
			
			webLogBean.setRequest(arr[6]);
			webLogBean.setStatus(arr[8]);
			webLogBean.setBody_bytes_sent(arr[9]);
			webLogBean.setHttp_referer(arr[10]);
			
			/**
			 * 因为浏览器信息不一致，所以从12个字段开始都是浏览器信息，
			 * 如果useragent元素较多，拼接useragent:
			 * 60.208.6.156 - - [18/Sep/2013:06:49:48 +0000] "GET /wp-content/uploads/2013/07/rcassandra.png HTTP/1.0" 200 185524 "http://cos.name/category/software/packages/" "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36"
			 */
			if(arr.length > 12){
				StringBuilder sb = new StringBuilder();
				for(int i=11;i<arr.length;i++){
					sb.append(arr[i]);
				}
				webLogBean.setHttp_user_agent(sb.toString());
			}else{
				//如果浏览器信息只有一个字段：
				webLogBean.setHttp_user_agent(arr[11]);
			}
			
			/**
			 * 状态码大于400，http错误
			 */
			if(Integer.parseInt(webLogBean.getStatus()) >= 400){
				webLogBean.setValid(false);
			}
			
			//访问时间错误：
			if("-invalid_time-".equals(webLogBean.getTime_local())){
				webLogBean.setValid(false);
			}
			
		}else{
			/**
			 * 如果字段小于11 缺省，就不合法
			 */
			webLogBean.setValid(false);
		}
		
		return webLogBean;
	}
	
	
	public static void filtStaticResource(WebLogBean bean , Set<String> pages){
		if(!pages.contains(bean.getRequest())){
			bean.setValid(false);
		}
	}
	
	public static String formatDate(String time_local){
		try{
			return df2.format(df1.parse(time_local));
		}catch (Exception e) {
			return null;
		}
	}
}
































