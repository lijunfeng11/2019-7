package com.webclick.mr.VisitMode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.webclick.daomain.PageViewsBean;
import com.webclick.daomain.VisitBean;
/**
* <p>Title: ClickStreamVisit</p>  
* <p>Description: 从pageviews模型（ClickStream）中进一步提炼出的visit模型；</p>  
* @author 优逸客大数据开发团队  
* @date 2018年10月1日
 */
public class ClickStreamVisit extends Configured implements Tool{

	private static class MapTask extends Mapper<LongWritable, Text, Text, PageViewsBean>{
		
		PageViewsBean pageView = new PageViewsBean();
		Text sessionId = new Text();
		
		@Override
		protected void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException {
			
			String line = value.toString();
			String[] tokens = line.split("\001");

			String session = tokens[0];
			String remote_addr = tokens[1];
			String remote_user = tokens[2];
			String time_local = tokens[3];
			String request = tokens[4];
			Integer step = Integer.valueOf(tokens[5]); //获取访问页面数
			String staylong = tokens[6];
			String referal = tokens[7];
			String useragent = tokens[8];
			String bytes_send = tokens[9];
			String status = tokens[10];
			
			pageView.set(session, remote_addr, remote_user, time_local, request, step, staylong, referal, useragent, bytes_send, status);
			
			sessionId.set(pageView.getSession());
			
			/*
			 * 一次会话，访问的所有页面的数据:
			 * sessionId 作为key;  value = 每个页面数据
			 */
			context.write(sessionId , pageView);
		}
	}
	
	
	private static class ReduceTask extends Reducer<Text, PageViewsBean, NullWritable, VisitBean>{
		
		@Override
		protected void reduce(Text sessionid, Iterable<PageViewsBean> iterator,Context context) throws IOException, InterruptedException {
			
			List<PageViewsBean> beans = new ArrayList<PageViewsBean>();
			
			for(PageViewsBean pvBean : iterator){
				
				PageViewsBean pageViewsBean = new PageViewsBean();
		
				try {
					BeanUtils.copyProperties(pageViewsBean, pvBean);
					//将bean添加到list中：目的：bean之间的排序
					beans.add(pageViewsBean);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			/*
			 * 按照访问页面的顺序降序排序：
			 * 比如：一个ip :第一个访问的页面 step = 1    www.baidu.com
			 * 							第二个访问的页面 step = 2    www.jd.com
			 * 							.........
			 * 							统计目录：可以按照访问的先后顺序来进行页面热度的业务指标分析；
			 */
			Collections.sort(beans , new Comparator<PageViewsBean>() {
				@Override
				public int compare(PageViewsBean o1, PageViewsBean o2) {
					return o1.getStep() > o2.getStep() ? 1 : -1;
				}
			});
			
			// 取这次visit的首尾pageview记录，将数据放入VisitBean中:
			VisitBean visitBean = new VisitBean();
			
			//当前session中访问的第一个页面信息：请求方式、请求url、http协议；
			visitBean.setInPage(beans.get(0).getRequest());
			//当前session中访问的第一个页面的时间；
			visitBean.setInTime(beans.get(0).getTimestr());
			
			//当前session中访问的最后一个页面信息
			visitBean.setOutPage(beans.get(beans.size() - 1).getRequest());
			//当前session中访问的最后一个页面的时间；
			visitBean.setOutTime(beans.get(beans.size() - 1).getTimestr());
			
			// visit访问的页面数
			visitBean.setPageVisits(beans.size());
			
			// 来访者的ip
			visitBean.setRemote_addr(beans.get(0).getRemote_addr());
			
			// 本次visit的referal
			visitBean.setReferal(beans.get(0).getReferal());
			
			visitBean.setSession(sessionid.toString());
			
			/*
			 * key = null , value = visit模型数据
			 */
			context.write(NullWritable.get(), visitBean);
		}
	}
	
	
	public static void main(String[] args) throws Exception {
		
		//本地测试：
		//args = new String[] {"testData/access.log" , "testData/preLog"};
		
		//集群测试：
		//args = new String[] {"/project/webClick/pageviewsModel" , "/project/webClick/visitModel"};
		
		Configuration conf = new Configuration();
		//conf.set("fs.defaultFS", "hdfs://node1:8020");
		
		//创建一个主类对象：
		ClickStreamVisit visit = new ClickStreamVisit();
		
		int status = ToolRunner.run(conf, visit , args);
		
		System.exit(status);
	}

	@Override
	public int run(String[] arg0) throws Exception {

		Configuration conf = getConf();
		
		Job job = Job.getInstance(conf , "visit模型");

		job.setJarByClass(ClickStreamVisit.class);

		job.setMapperClass(MapTask.class);
		job.setReducerClass(ReduceTask.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(PageViewsBean.class);

		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(VisitBean.class);

		FileInputFormat.setInputPaths(job, new Path(arg0[0]));
		FileOutputFormat.setOutputPath(job, new Path(arg0[1]));
		
		return job.waitForCompletion(true) ? 0 : 1;
	}
}




































